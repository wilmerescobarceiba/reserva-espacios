package com.ceiba.reserva.puerto.dao;

import java.util.List;

import com.ceiba.reserva.modelo.dto.DtoReserva;

public interface DaoReserva {
	List<DtoReserva> listar();

}
